#include <cstdio>

int main(){
	int a, b;
	scanf("%d %d", &a, &b);
	printf("%d\n", a * b - a + 1);
	return 0;
}
