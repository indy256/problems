#include<iostream>
using namespace std;

int main()
{
    int a, b, n, m;
    cin >> a >> b >> m >> n;
    cout << m + n * ( a - b ) << endl;
}
